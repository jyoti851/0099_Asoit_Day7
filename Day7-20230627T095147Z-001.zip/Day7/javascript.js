function stringLength(){
    var name=document.getElementById("name").value;
    document.getElementById('length').innerText=name.length;
}